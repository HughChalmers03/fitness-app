<?php
require($_SERVER['DOCUMENT_ROOT']."/header/index.php");
?>
<div class="container">
  <div class="heading">
    <p class="">Log in</p>
  </div>
  <div class="form-body">
    <form action="login.php" method="POST">
      <input name="username" class="input-form" type="text" placeholder="Name" autocomplete="off" /><br>
      <input name="password" class="input-form" type="password" placeholder="Password" autocomplete="off" /><br>
      <input type="submit" class="submit-btn" placeholder="Log in" />
    </form>
    <p class="signup-text">Or <a href="/fitness/signup">Sign Up</a> instead</p>
  </div>
</div>
