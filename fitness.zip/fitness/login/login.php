<center><br><br><br><br><br><br><br>
<?php
require($_SERVER['DOCUMENT_ROOT']."/header/index.php");
if(empty($_POST['username']) || empty($_POST['password'])) {
  throw_error("One or more of your inputs was empty", "../login");
  exit();
}
$username = htmlentities($conn->real_escape_string($_POST['username']));
$password = md5(htmlentities($conn->real_escape_string($_POST['password']))); // Using md5 to hash for simplicity of the project

$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>=1) {
  setcookie("username", $username, time() + (86400 * 30), "/");
  setcookie("password", $password, time() + (86400 * 30), "/");
  header("Location: /");
} else {
  throw_error("Invalid username or password", "../login");
  exit();
}
?>
