<?php
require($_SERVER['DOCUMENT_ROOT']."/fitness/header/auth.php");

function throw_error($msg, $redirect) { // This function will return an error message, with a link to $redirect
  echo "<div style='position:relative;top:30%;'>";
  echo "<center><p>$msg</p>";
  echo "<a href='$redirect'><button style='width:240px;padding:15px;font-size: 20px; -webkit-appearance: none; border-radius: 20px;color:white;cursor:pointer;border:none;'>Go back</button></a></center></div>";
  exit();
}
?>
<head>
  <title>Fitness</title>
  <link rel="stylesheet" type="text/css" href="/fitness/header/style.css" /> <!-- Link each page to global css file -->
  <link rel="stylesheet" type="text/css" href="style.css" /> <!-- Link each page to local css file -->
  <link rel="stylesheet" type="text/css" href="/fitness/header/circle.css" />
</head>
<body>
