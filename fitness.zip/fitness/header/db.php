<?php
/* This file will connect to the database */
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
  die("Connection to database failed: " . $conn->connect_error);
}
?>
