<?php
/* This script will authenticate the user is logged in. If they aren't, it will redirect to the login page. */
require($_SERVER['DOCUMENT_ROOT']."/fitness/header/db.php");

$page = $_SERVER['REQUEST_URI'];
$page = explode("?", $page)[0];
if(!strpos($page, "login") !== false && !strpos($page, "signup") !== false) { // Check the user isn't on the "login" or "signup" page
  $logged_in = "false";
  if(!isset($_COOKIE['username']) && !isset($_COOKIE['password'])){ // Check if the username and password cookies are set. If not, redirect to login
    header("Location: /fitness/login");
    exit();
  } else {
    // The following 2 lines will authenticate the string in the cookies to protect against SQL or xSS attacks
    $username = htmlentities($conn->real_escape_string($_COOKIE['username'])); // This takes the username from cookie "username"
    $password = htmlentities($conn->real_escape_string($_COOKIE['password'])); // This takes the password from cookie "password"

    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn,$sql); // Execute code above, which selects all fields from row where username and password are equal to cookies
    if(mysqli_num_rows($result)>=1) {
      $logged_in = "true"; // This checks that the cookies "username" and "password" exist in DB, then sets $logged_in to true
    } else {
      setcookie("username", "", time() - 3600); // This will delete the username and password cookies if they don't exist in the DB
      setcookie("password", "", time() - 3600);
      header("Location: /fitness/login");
    }
  }
}
?>
