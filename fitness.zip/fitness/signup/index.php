<?php
require($_SERVER['DOCUMENT_ROOT']."/fitness/header/index.php");
?>
<div class="container">
  <div class="heading">
    <p class="">Sign up</p>
  </div>
  <div class="form-body">
    <form action="signup.php" method="POST">
      <input name="fullname" class="input-form" type="text" placeholder="Full name" autocomplete="off" /><br>
      <input name="username" class="input-form" type="text" placeholder="Username" autocomplete="off" /><br>
      <input name="password" class="input-form" type="password" placeholder="Password" autocomplete="off" /><br>
      <input name="email" class="input-form" type="text" placeholder="Email" autocomplete="off" /><br>
      <input type="submit" class="submit-btn" placeholder="Log in" />
    </form>
    <p class="signup-text">Or <a href="/fitness/login">Log in</a> instead</p>
  </div>
</div>
